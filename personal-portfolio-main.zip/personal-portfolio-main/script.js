document.getElementById('downloadResume').addEventListener('click', function() {
    window.location.href = 'resume.pdf';
});
